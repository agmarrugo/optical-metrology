
function [dispx_reduced_raw,dispy_reduced_raw,dispx_reduced_interp,dispy_reduced_interp] = ...
    calc_disp_reduced(...
    N_pts_reduced,reduction,ref_image,N_images_correlated,...
    gridx_reduced,gridy_reduced,validx_reduced,validy_reduced,...
    grid_setup_reduced,loop_type,N_threads)

%% Calculate the average displacements of reduced correlation
        
if ref_image == 1 %First image
    
    gridx_full = repmat(gridx_reduced,1,N_images_correlated);
    gridy_full = repmat(gridy_reduced,1,N_images_correlated);
    
    %x-displacement of rough correlation at each point in the small grid, in the original coord sys
    dispx = (validx_reduced - gridx_full)*reduction; 
    
    %y-displacement of rough correlation at each point in the small grid, in the original coord sys
    dispy = (validy_reduced - gridy_full)*reduction; 
    


elseif ref_image == 2 %Preceeding image

    %Initialize empty vectors for the incremental displacement
    dispx_succ = zeros(size(validx_reduced));
    dispy_succ = zeros(size(validy_reduced));

    %Self-correlation of the first image
    dispx_succ(:,1) = (validx_reduced(:,1) - gridx_reduced(:,1))*reduction;
    dispy_succ(:,1) = (validy_reduced(:,1) - gridy_reduced(:,1))*reduction;

    %Calculate the displacements between each image
    for i = 2:N_images_correlated
        dispx_succ(:,i) = (validx_reduced(:,i) - validx_reduced(:,i-1))*reduction;
        dispy_succ(:,i) = (validy_reduced(:,i) - validy_reduced(:,i-1))*reduction;
    end

    %Calculate the total displacement from the reference image
    dispx = zeros(size(validx_reduced));
    dispy = zeros(size(validy_reduced));
    dispx(:,1) = dispx_succ(:,1);
    dispy(:,1) = dispy_succ(:,1);
    
    for i = 2:N_images_correlated
        sumx = zeros(N_pts_reduced,1);
        sumy = zeros(N_pts_reduced,1);
        for j = 1:i
            sumx = sumx + dispx_succ(:,j);
            sumy = sumy + dispy_succ(:,j);
        end

        dispx(:,i) = sumx;
        dispy(:,i) = sumy;
    end
end

%% Fill in any uncorrelated points with the by interpolating/extrapolating over the NaN values

%Get number of grid control points for reduced correlation
Ny = grid_setup_reduced.Ny;
Nx = grid_setup_reduced.Nx;

dispx_interp = zeros(Ny*Nx,N_images_correlated);
dispy_interp = zeros(Ny*Nx,N_images_correlated);

%Decide which type of loop to run
if strcmp(loop_type,'parallel') == 1
    parfor (i = 1:N_images_correlated,N_threads)
        
        [dispx_interp_i,dispy_interp_i] = interp_reduced_disp_loop(...
            gridx_reduced,gridy_reduced,dispx,dispy,i);
        
        dispx_interp(:,i) = dispx_interp_i;
        dispy_interp(:,i) = dispy_interp_i;
        
    end
    
elseif strcmp(loop_type,'serial') == 1
    for i = 1:N_images_correlated
        
        [dispx_interp_i,dispy_interp_i] = interp_reduced_disp_loop(...
            gridx_reduced,gridy_reduced,dispx,dispy,i);
        
        dispx_interp(:,i) = dispx_interp_i;
        dispy_interp(:,i) = dispy_interp_i;
        
    end
end

%Save both the raw disp_reduced data and the interpolated data
dispx_reduced_raw = dispx;
dispy_reduced_raw = dispy;
dispx_reduced_interp = dispx_interp;
dispy_reduced_interp = dispy_interp;

end

function [dispx_interp_i,dispy_interp_i] = interp_reduced_disp_loop(...
    gridx_reduced,gridy_reduced,dispx,dispy,i)

    %Remove NaN values from gridx_reduced,gridy_reduced, and disp_reduced
    ind_nan = isnan(dispx(:,i));
    gridx_num = gridx_reduced(~ind_nan);
    gridy_num = gridy_reduced(~ind_nan);
    dispx_num = dispx(~ind_nan,i);
    dispy_num = dispy(~ind_nan,i);

    %Create the interpolate/extrapolated displacement structures:
    dispx_interp_struct = scatteredInterpolant([gridx_num,gridy_num],dispx_num);
    dispy_interp_struct = scatteredInterpolant([gridx_num,gridy_num],dispy_num);

    %Interpolate over non-correlated data:
    dispx_interp_i = dispx_interp_struct(gridx_reduced,gridy_reduced);
    dispy_interp_i = dispy_interp_struct(gridx_reduced,gridy_reduced);

end

        

