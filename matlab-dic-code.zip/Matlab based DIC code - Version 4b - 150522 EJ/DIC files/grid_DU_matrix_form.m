%This function reshapes the gridx_DU and gridy_DU vectors into matrices
%(similar to the x_matrix and y_matrix for the grid of control poitns for
%displacements)

function [x_matrix_DU_NaN,y_matrix_DU_NaN] = grid_DU_matrix_form(...
    grid_param,gridx_DU,gridy_DU,scale)

%Step size (same for displacement grid and strain grid)
step = grid_param.step*scale;

%Min and max values for the grid_DU
xmin = min(gridx_DU);
xmax = max(gridx_DU);
ymin = min(gridy_DU);
ymax = max(gridy_DU);

%Matrix form of complete grid_DU points (including all that may be
%deleted from interior of the ROI, but not from the edge of the ROI if entire 
%rows/colums were deleted from edge)
xvec_DU = xmin:step:xmax;
yvec_DU = ymin:step:ymax;
[x_matrix_DU,y_matrix_DU] = meshgrid(xvec_DU,yvec_DU);
[Ny_DU,Nx_DU] = size(x_matrix_DU);

%Reshape the complete grid_DU matrices into vectors
gridx_DU_complete = reshape(x_matrix_DU,[],1);
gridy_DU_complete = reshape(y_matrix_DU,[],1);

%Compare the "complete" grid_DU (which includes any deleted points) with
%the actual grid_DU (which doesn't contain any deleted points from
%delete_data_GUI)
grid_DU_complete = [gridx_DU_complete,gridy_DU_complete];
grid_DU_real = [gridx_DU,gridy_DU];

%Round both grids to the nearest hundredth before comparing
grid_DU_complete = round(grid_DU_complete.*10^2) / 10^2;
grid_DU_real = round(grid_DU_real.*10^2) / 10^2;
ind_member = ismember(grid_DU_complete,grid_DU_real,'rows');

%Replace all the deleted points with NaN in the complete grid_DU vectors
grid_DU_complete_NaN = grid_DU_complete;
grid_DU_complete_NaN(~ind_member,:) = NaN;

%Reshape the vectors back into matrices
x_matrix_DU_NaN = reshape(grid_DU_complete_NaN(:,1),Ny_DU,Nx_DU);
y_matrix_DU_NaN = reshape(grid_DU_complete_NaN(:,2),Ny_DU,Nx_DU);

